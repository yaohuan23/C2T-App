import sys
import numpy as np

def analyze_and_update_records(file_path, output_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        records = [line for line in file if line.strip()]

    updated_records = []
    i = 0

    while i < len(records):
        record_name = records[i].strip()
        i += 1

        if i < len(records) and not records[i].startswith('>'):
            record_description = records[i].strip()
            i += 1
        else:
            record_description = ""

        content_lengths = []
        t_ending_count = 0
        record_content_with_lengths = []

        while i < len(records) and not records[i].startswith('>'):
            record_content = records[i].strip()
            content_length = len(record_content)
            t_ending_count += record_content.endswith('t')
            content_lengths.append(content_length)
            record_content_with_lengths.append(f"{record_content}\t{content_length}")
            i += 1

        median_length = np.median(content_lengths) if content_lengths else 0
        mean_length = np.mean(content_lengths) if content_lengths else 0

        lengths_str = ";".join(map(str, content_lengths))
        updated_record_name = f"{record_name}\t{len(content_lengths)}-{t_ending_count}\t{lengths_str}\t{median_length:.1f}\t{mean_length:.1f}"

        updated_records.append(updated_record_name + '\n')
        if record_description:
            updated_records.append(record_description + '\n')
        updated_records.extend([line + '\n' for line in record_content_with_lengths])

    with open(output_path, 'w', encoding='utf-8') as output_file:
        output_file.writelines(updated_records)

if __name__ == "__main__":
    input_file_path = sys.argv[1]
    output_file_path = sys.argv[2]

    analyze_and_update_records(input_file_path, output_file_path)
