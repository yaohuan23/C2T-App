a=($(wc -l Aligned-for-plot-CoutA-re.txt))
echo ${a[0]}
if [[ ${a[0]} -gt 1237 ]]; then
echo 123
echo ${a[@]}
fi
