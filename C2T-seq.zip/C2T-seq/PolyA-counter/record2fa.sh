 awk 'FNR<3{print $0} FNR>=3{print ">reads"FNR-2;print $0}'  41.fa > peaks9441-1.fa
