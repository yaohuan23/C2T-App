from PIL import Image

def process_text(input_file, output_file):
    with open(input_file, 'r') as file:
        lines = file.readlines()

    color_dict = {'-': (0, 191, 255), 'other': (255, 0, 0)}
    block_size = 20
    line_height = 20
    image_width = min(300, max(len(line) for line in lines)) * block_size
    image_height = len(lines) * line_height

    image = Image.new('RGB', (image_width, image_height), (255, 255, 255))
    pixels = image.load()

    for i, line in enumerate(lines):
        line = line.strip()
        for j, char in enumerate(line):
            if char in color_dict:
                color = color_dict[char]
            else:
                color = color_dict['other']
            for x in range(j * block_size, (j + 1) * block_size):
                for y in range(i * line_height, (i + 1) * line_height):
                    pixels[x, y] = color

    image.save(output_file)
    print(f"Image saved as {output_file}")

# 示例用法
input_file = "plot.txt"  # 输入文本文件名
output_file = "output.png"  # 输出图片文件名
process_text(input_file, output_file)

