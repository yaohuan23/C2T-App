def read_fasta(filename):
    sequences = {}
    current_seq = ""

    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                current_seq = line[1:]
                sequences[current_seq] = ""
            else:
                sequences[current_seq] += line

    return sequences

def calculate_polyA_stats(reference, reads):
    stats = []

    for read_name, read_seq in reads.items():
        trimmed_sequence = ""
        consecutive_a_count = 0
        for base in read_seq:
            if base == 'A':
                consecutive_a_count += 1
                if consecutive_a_count <= 10:
                    trimmed_sequence += 'A'
                else:
                    pass  # 超过10个A时不添加到序列中
            else:
                consecutive_a_count = 0
                trimmed_sequence += base 
        if consecutive_a_count > 10:
            trimmed_sequence = trimmed_sequence[:-10]
        print(trimmed_sequence)
        alignment_result = dynamic_alignment(reference, trimmed_sequence)
        align_seq1, align_midline, align_seq2 = alignment_result

        read_length = len(align_seq2)

        # 找出测序阅读中最后一个与参考序列匹配的位置
        last_match_index = -1
        for i in range(read_length - 1, -1, -1):
            if align_seq1[i] == align_seq2[i]:
                # 检查是否持续匹配了至少5个碱基
                if i >= 4 and all(align_seq1[j] == align_seq2[j] for j in range(i - 4, i + 1)):
                    last_match_index = i
                    break

        if last_match_index != -1:
            aligned_extra_seq = align_seq2[last_match_index + 1:]
            aligned_extra_length = len(aligned_extra_seq)
        else:
            aligned_extra_seq = ""
            aligned_extra_length = 0

        a_count = aligned_extra_seq.count('A')
        a_ratio = a_count / aligned_extra_length if aligned_extra_length > 0 else 0

        stats.append([read_name,aligned_extra_seq, aligned_extra_length, a_ratio, align_seq1, align_midline, align_seq2])

    return stats

def print_stats(stats):
    print("序列\t超出部分序列\t超出部分长度\t超出部分中的A比例\t比对结果")
    for stat in stats:
        read_name, extra_seq,extra_length, a_ratio, align_seq1, align_midline, align_seq2 = stat
        print(f"{read_name}\t{extra_seq}\t{extra_length}\t{a_ratio:.2f}")

        align_lines = [align_seq1, align_midline, align_seq2]
        max_line_length = max(len(line) for line in align_lines)

        for line in align_lines:
            print(line.ljust(max_line_length))

        print()

def simple_align(seq1, seq2):
    reAlign_result = ""
    for i in range(len(seq2)):
        if seq2[i] != seq1[i]:
            reAlign_result = seq2[i:]
            break
        reAlign_result = None
    return i, reAlign_result

def dynamic_alignment(seq1, seq2):
    # 初始化比对得分和惩罚
    match_score = 1
    min_gap_penalty = -1
    max_gap_penalty = -1

    # 初始化得分矩阵
    scores = [[0] * (len(seq2) + 1) for _ in range(len(seq1) + 1)]

    # 初始化方向矩阵
    directions = [[''] * (len(seq2) + 1) for _ in range(len(seq1) + 1)]

    # 记录连续比对的长度
    continuous_match_length = 0

    # 填充矩阵
    for i in range(1, len(seq1) + 1):
        for j in range(1, len(seq2) + 1):
            if seq1[i-1] == seq2[j-1]:
                scores[i][j] = scores[i-1][j-1] + match_score
                continuous_match_length += 1
            else:
                scores[i][j] = max(scores[i-1][j] + min_gap_penalty, scores[i][j-1] + min_gap_penalty)
                continuous_match_length = 0

            #if continuous_match_length >= 5:
            #    min_gap_penalty = max_gap_penalty

            if scores[i][j] == scores[i-1][j] + min_gap_penalty:
                directions[i][j] = 'up'
            elif scores[i][j] == scores[i][j-1] + min_gap_penalty:
                directions[i][j] = 'left'
            else:
                directions[i][j] = 'diagonal'

    # 回溯构建比对结果
    align_seq1 = ''
    align_seq2 = ''
    align_midline = ''
    i, j = len(seq1), len(seq2)

    while i > 0 and j > 0:
        direction = directions[i][j]
        if direction == 'diagonal':
            align_seq1 = seq1[i-1] + align_seq1
            align_seq2 = seq2[j-1] + align_seq2
            if seq1[i-1] == seq2[j-1]:
                align_midline = '|' + align_midline
            else:
                align_midline = ' ' + align_midline
            i -= 1
            j -= 1
        elif direction == 'up':
            align_seq1 = seq1[i-1] + align_seq1
            align_seq2 = '-' + align_seq2
            align_midline = ' ' + align_midline
            i -= 1
        else:
            align_seq1 = '-' + align_seq1
            align_seq2 = seq2[j-1] + align_seq2
            align_midline = ' ' + align_midline
            j -= 1

    while i > 0:
        align_seq1 = seq1[i-1] + align_seq1
        align_seq2 = '-' + align_seq2
        align_midline = ' ' + align_midline
        i -= 1

    while j > 0:
        align_seq1 = '-' + align_seq1
        align_seq2 = seq2[j-1] + align_seq2
        align_midline = ' ' + align_midline
        j -= 1

    return align_seq1, align_midline, align_seq2

