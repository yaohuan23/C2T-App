#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source activate yaohuan23
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""
POLYAFA="/public23/home/sca2382/Ref/Annotations/human/PolyA/gencode.v44.polyAs.around200-nochr.fa"
SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
  if [ ! -f $1 ];then
  continue
  fi
  dir=${1%/*}
  filename1=${1%%.*}
  filename=${filename1##*/}
  cd ${dir}
    awk 'NR==FNR{getline a; x[$1]=a}NR>FNR{if(x[$1]){print $1;print x[$1]}else{print $0}}' ${POLYAFA} ${filename}.fa > ${filename}-1.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,1,length(a)-7);getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' human-polyA-paire.fastq  ${filename}-1.fa > ${filename}-polyA.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,1,length(a)-7);getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ../tmp/human-polyA-Toolong_1.fastq  ${filename}-1.fa > ${filename}-ToolongPolyA.fa
    grep -v "@" ${filename}-polyA.fa > ${filename}-temp
    mv ${filename}-temp  ${filename}-polyA.fa
    grep -v "@" ${filename}-ToolongPolyA.fa > ${filename}-temp
    mv ${filename}-temp  ${filename}-ToolongPolyA.fa
}
pipelineOne() {
while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  continue
  fi
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  cd ${dir}
  bamCoverage --binSize 1  --normalizeUsing RPKM -b ${line} -o ${filename}.bw &
done 
}
while read line;
do
pipeline ${line}
done < $1
