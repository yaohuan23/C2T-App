import sys
def local_sequence_alignment(seq1, seq2, match_score=1, mismatch_penalty=-1, gap_penalty=-1):
    """实现一个简化的局部序列比对算法"""
    m, n = len(seq1), len(seq2)
    score_matrix = [[0 for _ in range(n + 1)] for _ in range(m + 1)]

    max_score = 0
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if seq1[i-1] == seq2[j-1]:
                score = match_score
            else:
                score = mismatch_penalty

            score_matrix[i][j] = max(
                0,
                score_matrix[i-1][j-1] + score,
                score_matrix[i-1][j] + gap_penalty,
                score_matrix[i][j-1] + gap_penalty
            )
            max_score = max(max_score, score_matrix[i][j])

    return max_score

def process_and_filter_records(file_path):
    records = {}
    current_record = None
    current_description = None
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('>'):
                current_record = line
                current_description = None
            elif current_record and not current_description:
                current_description = line
                if current_record not in records:
                    records[current_record] = [current_description, []]
            else:
                if current_record and current_description:
                    records[current_record][1].append(line)

    filtered_records = {}
    for record, (description, contents) in records.items():
        # 首先排除前20个碱基中含有超过60%的A的记录
        pre_filtered_contents = [content for content in contents if content[:20].count('A') / 20 <= 0.6]
        # 使用局部序列比对算法进一步过滤记录
        filtered_contents = [content for content in pre_filtered_contents 
                             if local_sequence_alignment(content[:20], description, match_score=1, mismatch_penalty=-1, gap_penalty=-1) >= 5]
        if filtered_contents:
            filtered_records[record] = (description, filtered_contents)

    return records

if __name__ == "__main__":
    file_path = sys.argv[1]
    processed_records = process_and_filter_records(file_path)

    for record, (description, contents) in processed_records.items():
        print(record)
        print(description)
        for content in contents:
            print(content)

# 请确保您的 'temp.fa' 文件路径是正确的。

