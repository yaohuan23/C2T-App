#!/public23/home/sca2382/.conda/envs/yaohuan23/bin/python
import sys
import json
from TailAlign import *
fasta_file = sys.argv[1]

# 读取参考序列和测序阅读数据
sequences = read_fasta(fasta_file)

# 读取参考序列和测序阅读数据
reference_sequence = None
reads_sequences = {}
readCounter = 1

for seq_name, seq_data in sequences.items():
    reference_sequence = seq_data
    reference_name = seq_name
    #print(seq_name)
    #print(seq_data)
    break

if reference_sequence is not None:
    sequences.pop(seq_name)
    reads_sequences = sequences

for seq_name, seq_data in reads_sequences.items():
    re_align_read = simple_align(reference_sequence, seq_data)
    bisPosition = int(re_align_read[0])
    polyATail = re_align_read[1]
    if polyATail is not None:
        nowRefseq = reference_sequence[bisPosition:len(reference_sequence)-1]
        nowRef = f"{nowRefseq}\t{reference_name}\t{bisPosition}"
        tailLength = len(polyATail)
        nowRecord = f"{nowRef}\t{polyATail}\treads{readCounter}\t{tailLength}"
        print(nowRecord)
    readCounter +=1
