import sys
def process_records(file_path):
    with open(file_path, 'r') as file:
        records = {}
        current_record = None
        current_description = None

        for line in file:
            line = line.strip()
            if line.startswith('>'):  # 记录名称
                current_record = line
                current_description = None
            elif current_record and not current_description:  # 记录说明
                current_description = line
                records[current_record] = [current_description, []]
            else:  # 记录内容
                if current_record and current_description:
                    processed_line = process_line(line)
                    records[current_record][1].append(processed_line)

    return records

def process_line(line):
    for i in range(len(line) - 1, 1, -1):
        if line[i] != 'A' and line[i - 1] != 'A':
            for j in range(i + 1, len(line)):
                if line[j] == 'A':
                    return line[j:].lower()
            break
    return line.lower()

# 指定的文件路径
file_path = sys.argv[1] 

# 处理记录
processed_records = process_records(file_path)

# 打印处理并排序后的记录
for record, (description, contents) in processed_records.items():
    print(record)
    print(description)
    # 对每个记录下的内容按处理后的字符串长度进行排序
    sorted_contents = sorted(contents, key=len, reverse=True)
    for content in sorted_contents:
        print(content)
    print()

