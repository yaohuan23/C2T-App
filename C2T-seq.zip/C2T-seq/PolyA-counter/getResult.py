import sys
import json
from TailAlign import *
fasta_file = sys.argv[1]
json_file = sys.argv[2]

# 读取参考序列和测序阅读数据
sequences = read_fasta(fasta_file)

# 读取参考序列和测序阅读数据
reference_sequence = None
reads_sequences = {}

for seq_name, seq_data in sequences.items():
    reference_sequence = seq_data
    break

if reference_sequence is not None:
    # 删除第一个记录，即参考序列
    sequences.pop(seq_name)

    # 剩下的记录为测序阅读数据
    reads_sequences = sequences
    # 计算每条阅读中超出参考序列部分的序列长度、A比例和比对结果
    stats = calculate_polyA_stats(reference_sequence, reads_sequences )
    #print(stats)
    # 保存结果到指定的JSON文件
    with open(json_file, 'w') as output_file:
        json.dump(stats, output_file)
else:
    print("未找到参考序列")

