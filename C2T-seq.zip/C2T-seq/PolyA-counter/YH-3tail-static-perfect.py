#!/public23/home/sca2382/.conda/envs/yaohuan23/bin/python
from __future__ import print_function
from __future__ import division
import sys
import csv
import statistics
from argparse import ArgumentParser

sys.path.append("/public23/home/sca2382/script/hisat2_RNA-seq/YH-tans-app")
from src.samtreater import bedFilter

if __name__ == '__main__':
    description = "write the PolyA result in a csv file"
    parser = ArgumentParser(description=description)
    parser.add_argument('-i', '--inputfile', type=str, help="you should input a pregtf file")
    parser.add_argument('-o', '--output', type=str, help="you should input a file where the result to put")
    args = parser.parse_args()

    if not args.inputfile or not args.output:
        parser.print_help()
        sys.exit(1)

    inputA = args.inputfile
    outPutCSV = args.output

    with open(inputA, 'r') as Ifile, open(outPutCSV, 'w', newline='') as outfile:
        reader = csv.reader(Ifile)
        writer = csv.writer(outfile)

        for row in reader:
            columns = row[2].split(';')
            third_column_values = [int(value) for value in columns if value.strip()]

            if third_column_values:
                median = statistics.median(third_column_values)
                average = round(statistics.mean(third_column_values), 1)  # 保留一位小数
                row.append(str(median))
                row.append(str(average))
                row.append(str(len(third_column_values)))

            writer.writerow(row)
