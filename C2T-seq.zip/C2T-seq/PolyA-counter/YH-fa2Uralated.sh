
awk '$1~/AAAAAAAAA[A,T]{1,}T$/{print FNR}' MII-all-perfect.txt > U.record
awk '$1~/::/{print FNR}' MII-all-perfect.txt >> U.record



awk 'NR==FNR{x[$1]=1}NR>FNR{if(x[FNR]==1){print $0}}' U-record.txt GV-all-perfect.txt |awk '{a=$0;if(a~/::/){getline;if ($1 !~ /::/) {print a;print $0}}else{print $0}}' > gene-U.record.result

awk 'BEGIN{count=0;record=""}{if($0~/::/){print record,count;count=0;record=$0}else{count +=1}}END{print record,count}' gene-U.record > result-gene-U.record.txt

awk 'NR==FNR{x[$1]==1}NR>FNR{if(x[FNR]==1){print $0}}' U.record MII-all-perfect.txt|awk '{a=$0;if(a~/::/){getline;if ($1 !~ /::/) {print a;print $0}}else{print $0}}' |sed '1d' > gene-U.record
sed -i 's/>//g' result-gene-U.record.txt
awk 'BEGIN{record="";count=0} {if(record==$1){count +=1}else{print record,count;record=$1;count=$2}} END{print record,count}' result-gene-U.record.txt |sed '1d' > result-gene-U.record-1.txt

