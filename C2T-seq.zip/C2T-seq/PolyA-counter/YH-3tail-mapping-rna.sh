#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME} [output_dir]
Wrapper script for HISAT2/StringTie RNA-Seq analysis protocol.
In order to configure the pipeline options (input/output files etc.)
please copy and edit a file rnaseq_pipeline.config.sh which must be
placed in the current (working) directory where this script is being launched.

Output directories "hisat2" and "ballgown" will be created in the
current working directory or, if provided, in the given <output_dir>
(which will be created if it does not exist).

EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

## load variables
if [[ ! -f $2 ]]; then
 usage
 echo "Error: configuration file (rnaseq_pipeline.config.sh) missing!"
 exit 1
fi

source $2
WRKDIR=$(pwd -P)
errprog=""
if [[ ! -x $SAMTOOLS ]]; then
    errprog="samtools"
fi
if [[ ! -x $HISAT2 ]]; then
    errprog="hisat2"
fi
if [[ ! -x $STRINGTIE ]]; then
    errprog="stringtie"
fi

if [[ "$errprog" ]]; then
  echo "ERROR: $errprog program not found, please edit the configuration script."
  exit 1
fi

#if [[ ! -f rnaseq_ballgown.R ]]; then
#   echo "ERROR: R script rnaseq_ballgown.R not found in current directory!"
#   exit 1
#fi

#determine samtools version
newsamtools=$( ($SAMTOOLS 2>&1) | grep 'Version: 1\.')
set -e
#set -x

if [[ $OUTDIR != "." ]]; then
  mkdir -p $OUTDIR
  cd $OUTDIR
fi

SCRIPTARGS="$@"
ALIGNLOC=$OUTDIR/hisat2
BALLGOWNLOC=$OUTDIR/ballgown

LOGFILE=$OUTDIR/run.log

for d in "$TEMPLOC" "$ALIGNLOC" "$BALLGOWNLOC" ; do
 if [ ! -d $d ]; then
    mkdir -p $d
 fi
done

# main script block
pipeline() {

echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> START: " $0 $SCRIPTARGS

for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    #sample="${sample%%_*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    echo [$stime] "   * Alignment of reads to genome (HISAT2)"
    NGmerge -1 ${reads1[$i]} -2  ${reads2[$i]} -o ${ALIGNLOC}/${sample}-paire.fastq -l ${TEMPLOC}/${sample}-pairelog.txt  -f ${TEMPLOC}/${sample}-Toolong
if [[ ! -f ${TEMPLOC}/${sample}-10.bam ]];then
     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7  \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-0.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 10 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-10.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 20 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-20.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 30 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-30.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 40 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-40.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 50 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-50.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 60 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-60.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 70 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-70.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 80 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-80.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 90 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-90.bam 2>${ALIGNLOC}/${sample}.alnstats &

     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${reads1[$i]} \
     --rna-strandness F --add-chrname -5 7 -3 100 \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-100.bam 2>${ALIGNLOC}/${sample}.alnstats &
fi
wait
    samtools view ${TEMPLOC}/${sample}-0.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-0-poly.record
    samtools view ${TEMPLOC}/${sample}-10.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-10-poly.record
    samtools view ${TEMPLOC}/${sample}-20.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-20-poly.record
    samtools view ${TEMPLOC}/${sample}-30.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-30-poly.record
    samtools view ${TEMPLOC}/${sample}-40.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-40-poly.record
    samtools view ${TEMPLOC}/${sample}-50.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-50-poly.record
    samtools view ${TEMPLOC}/${sample}-60.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-60-poly.record
    samtools view ${TEMPLOC}/${sample}-70.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-70-poly.record
    samtools view ${TEMPLOC}/${sample}-80.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-80-poly.record
    samtools view ${TEMPLOC}/${sample}-90.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-90-poly.record
    samtools view ${TEMPLOC}/${sample}-100.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-100-poly.record
    cat ${ALIGNLOC}/${sample}-0-poly.record ${ALIGNLOC}/${sample}-10-poly.record ${ALIGNLOC}/${sample}-20-poly.record ${ALIGNLOC}/${sample}-30-poly.record ${ALIGNLOC}/${sample}-40-poly.record ${ALIGNLOC}/${sample}-50-poly.record ${ALIGNLOC}/${sample}-60-poly.record ${ALIGNLOC}/${sample}-70-poly.record ${ALIGNLOC}/${sample}-80-poly.record ${ALIGNLOC}/${sample}-90-poly.record ${ALIGNLOC}/${sample}-100-poly.record > ${ALIGNLOC}/${sample}-poly.record
    #grep "XT:" ${ALIGNLOC}/${sample}-poly.record > temp
    #mv temp ${ALIGNLOC}/${sample}-poly.record
    awk '$1 ~/-*TTTTT*$/{print "@"$0}' ${ALIGNLOC}/${sample}-poly.record|sort|uniq |sort -k2> ${ALIGNLOC}/${sample}-r3tURecord.txt
    sed -i 's/\tchr/\t/g' ${ALIGNLOC}/${sample}-r3tURecord.txt 
    awk 'BEGIN{nowSite=""}{if(nowSite==$2){print $1}else{print ">"$2;print $1;nowSite=$2}}' ${ALIGNLOC}/${sample}-r3tURecord.txt > ${ALIGNLOC}/${sample}-pre.fa
awk 'NR==FNR{getline a; x[$1]=a}NR>FNR{if(x[$1]){print $1;print x[$1]}else{print $0}}' /public23/home/sca2382/Ref/Annotations/mouse/polyA/gencode.vM25.polyAsAround200.fa ${ALIGNLOC}/${sample}-pre.fa > ${ALIGNLOC}/${sample}-pre-1.fa
awk 'NR==FNR{getline a; x[$1]=a;getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${ALIGNLOC}/${sample}-paire.fastq  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-polyA.fa
awk 'NR==FNR{getline a; x[$1]=a;getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${TEMPLOC}/${sample}-Toolong_1.fastq  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-ToolongPolyA.fa
done
echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> DONE."
} #pipeline end


pipelineTwo() {

echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> START: " $0 $SCRIPTARGS

for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    #sample="${sample%%_*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    echo [`date +"%Y-%m-%d %H:%M:%S"`] "   * Alignments conversion (SAMTools)"
if [[ ! -f ${ALIGNLOC}/${sample}-3tURecord.txt ]]; then  
	intersectBed -a ${TEMPLOC}/${sample}-0.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-0-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-10.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-10-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-20.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-20-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-30.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-30-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-40.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-40-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-50.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-50-poly.bam

	intersectBed -a ${TEMPLOC}/${sample}-60.bam  -b /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.polyAsAround200.gtf > ${ALIGNLOC}/${sample}-60-poly.bam

fi

done
echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> DONE."
} #pipeline end


pipelineThree() {
for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    samtools view ${TEMPLOC}/${sample}-0.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-0-poly.record
    samtools view ${TEMPLOC}/${sample}-10.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-10-poly.record
    samtools view ${TEMPLOC}/${sample}-20.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-20-poly.record
    samtools view ${TEMPLOC}/${sample}-30.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-30-poly.record
    samtools view ${TEMPLOC}/${sample}-40.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-40-poly.record
    samtools view ${TEMPLOC}/${sample}-50.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-50-poly.record
    samtools view ${TEMPLOC}/${sample}-60.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-60-poly.record
    cat ${ALIGNLOC}/${sample}-0-poly.record ${ALIGNLOC}/${sample}-10-poly.record ${ALIGNLOC}/${sample}-20-poly.record ${ALIGNLOC}/${sample}-30-poly.record ${ALIGNLOC}/${sample}-40-poly.record ${ALIGNLOC}/${sample}-50-poly.record ${ALIGNLOC}/${sample}-60-poly.record > ${ALIGNLOC}/${sample}-poly.record
    #grep "XT:" ${ALIGNLOC}/${sample}-poly.record > temp
    #mv temp ${ALIGNLOC}/${sample}-poly.record
    awk '$1 ~/-*TTTTT*$/{print "@"$0}' ${ALIGNLOC}/${sample}-poly.record|sort|uniq |sort -k2> ${ALIGNLOC}/${sample}-r3tURecord.txt
    sed -i 's/\tchr/\t/g' ${ALIGNLOC}/${sample}-r3tURecord.txt 
    awk 'BEGIN{nowSite=""}{if(nowSite==$2){print $1}else{print ">"$2;print $1;nowSite=$2}}' ${ALIGNLOC}/${sample}-r3tURecord.txt > ${ALIGNLOC}/${sample}-pre.fa
awk 'NR==FNR{getline a; x[$1]=a}NR>FNR{if(x[$1]){print $1;print x[$1]}else{print $0}}' /public23/home/sca2382/Ref/Annotations/mouse/polyA/gencode.vM25.polyAsAround200.fa ${ALIGNLOC}/${sample}-pre.fa > ${ALIGNLOC}/${sample}-pre-1.fa
awk 'NR==FNR{getline a; x[$1]=a;getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}'   ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-polyA.fa
done
} #pipline END

pipeline 2>&1 | tee $LOGFILE
wait
#pipelineTwo 2>&1 | tee $LOGFILE
#wait
#pipelineThree 2>&1 | tee $LOGFILE
#wait
