import os
import sys

def process_records_v3(input_file, barcode_file, output_directory=None):
    # Reading barcodes
    with open(barcode_file, 'r') as file:
        barcodes = [line.strip() for line in file.readlines()]

    # Initialize a dictionary to hold records for each barcode
    barcode_records = {barcode: {} for barcode in barcodes}

    # Set the output directory to the current directory if not provided
    if not output_directory:
        output_directory = os.getcwd()

    # Read and process the input file
    with open(input_file, 'r') as file:
        current_record_name = ""
        for line in file:
            if line.startswith('>'):
                current_record_name = line.strip()
                for barcode in barcodes:
                    barcode_records[barcode][current_record_name] = []
            elif line.startswith('@'):
                parts = line.strip().split('-')
                if len(parts) > 3:
                    label = parts[3]
                    if label in barcode_records:
                        barcode_records[label][current_record_name].append(line)

    # Create output directory if it doesn't exist
    os.makedirs(output_directory, exist_ok=True)

    # Write the filtered records to separate files
    for barcode, record_names in barcode_records.items():
        output_file_path = os.path.join(output_directory, f"{barcode}_records.fa")
        with open(output_file_path, 'w') as file:
            for record_name, records in record_names.items():
                if records:
                    file.write(record_name + '\n')
                    file.writelines(records)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python script.py <input_file> <barcode_file> [output_directory]")
        sys.exit(1)

    input_file = sys.argv[1]
    barcode_file = sys.argv[2]
    output_directory = sys.argv[3] if len(sys.argv) > 3 else None

    process_records_v3(input_file, barcode_file, output_directory)
    print("Processing complete. Check the output directory for results.")

