#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source conda activate yaohuan23
#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
  cd $2
 awk 'BEGIN{now=""}{if($2~/chr/){now=FNR;print $0 >"YHpolyAtemp"now".txt"}else{print $0 > "YHpolyAtemp"now".txt"}}' $1

}
pipseq(){
	cd $2
 	echo "sample $1 is being treated"
	awk 'BEGIN{num=0;jobnum=1}{if($2~/chr/){if(num<100){num+=1;print $0 > "seperatedjobs-"jobnum".txt"}else{num=1;jobnum+=1;print $0 > "seperatedjobs-"jobnum".txt"}}else{print $0 > "seperatedjobs-"jobnum".txt"}}' $1

}
pipelineOne() {
	cd $2
	filename1=${1%%.*}
	filename=${filename1##*/}
 	awk 'FNR<3{print $0} FNR>=2{print ">reads"FNR-1;print $0}'  $1 > ${filename}-temp-alin-1.txt
	Areadsnum=($(wc -l ${filename}-temp-alin-1.txt))
	if [ ${Areadsnum[0]} -lt 500 ] && [ ${Areadsnum[0]} -gt 2 ]; then
  	  awk 'BEGIN{OFS="\t"}NR==1{a=$2"\t"$1"\t"}NR>1{a=a";"$3}END{print a}' ${filename}-temp-alin-1.txt >${filename}-Aligned-for-plot-CoutA-re.txt
	fi
}

while read line;
do
	dir=${line%/*}
	filename1=${line%%.*}
	filename=${filename1##*/}
	mkdir ${dir}/${filename}
	pipseq ${line} ${dir}/${filename}
	wait
	find ${dir}/${filename} -name seperatedjobs\* > ${dir}/${filename}/${filename}-joblist.txt
	while read linea;
	do
		dir2=${linea%/*}
		filename1=${linea%%.*}
		filename2=${filename1##*/}
		mkdir ${dir2}/${filename2}
		pipeline ${linea} ${dir2}/${filename2}
		wait
		find ${dir2}/${filename2} -name YHpolyAtemp\* > ${dir2}/${filename2}/${filename2}-precal.txt
		while read lineb;
		do
			pipelineOne ${lineb}  ${dir2}/${filename2} & 
		done < ${dir2}/${filename2}/${filename2}-precal.txt  
		wait
		cat ${dir2}/${filename2}/*Aligned-for-plot-CoutA-re.txt > ${dir2}/${filename2}/result.txt
		rm ${dir2}/${filename2}/YHpolyAtemp*.txt
	       #rm ${dir2}/${filename2}/*temp-alin-1.txt
	       # rm ${dir2}/${filename2}/*Aligned-temp
	       # rm ${dir2}/${filename2}/*Aligned-temp.align.txt
	       # rm ${dir2}/${filename2}/*APA-star.LocalSite
	       # rm ${dir2}/${filename2}/*temp.fasta
		rm ${linea}
		rm ${dir2}/${filename2}/${filename2}-precal.txt
	done < ${dir}/${filename}/${filename}-joblist.txt  
	wait
	find ${dir}/${filename} -name result.txt|xargs cat > ${dir}/${filename}/${filename}.polyA-result.txt
	rm -r ${dir}/${filename}/seperatedjobs*
        sed -i 's/\t;/\t/g' ${dir}/${filename}/${filename}.polyA-result.txt
        sed -i 's/;;/;/g' ${dir}/${filename}/${filename}.polyA-result.txt
	sed -i 's/\t/,/g' ${dir}/${filename}/${filename}.polyA-result.txt
        sort -k1 ${dir}/${filename}/${filename}.polyA-result.txt |awk 'BEGIN{FS=",";now="";record=""}{if($1!=now){print record;record=$0;now=$1}else{record=record";"$3}}END{print record}' | sed '1d' > ${dir}/${filename}/${filename}.byTrans-result.txt
	~/script/myscript/C2T-seq/PolyA-counter/YH-3tail-static-perfect.py -i ${dir}/${filename}/${filename}.polyA-result.txt  -o ${dir}/${filename}/${filename}.polyA-result.csv
	sed -i '1i  PolyASite,siteRef,transID,geneID,Arecord,Meida,Average,Count ' ${dir}/${filename}/${filename}.polyA-result.csv
	sed -i 's/,/\t/g'  ${dir}/${filename}/${filename}.polyA-result.csv
	awk 'NR==FNR{a=substr($1,1,15);x[a]=$0} NR>FNR{$1=x[$1];print $0}' ~/Ref/Annotations/mouse/polyA/polyASites2GeneAndTrans.txt  ${dir}/${filename}/${filename}.polyA-result.csv > ${dir}/${filename}/temp	
	mv ${dir}/${filename}/temp ${dir}/${filename}/${filename}.polyA-result.tsv
	sed 's/\t/,/g' ${dir}/${filename}/${filename}.polyA-result.tsv > ${dir}/${filename}/${filename}.polyA-result.csv

	~/script/myscript/C2T-seq/PolyA-counter/YH-3tail-static-perfect.py -i ${dir}/${filename}/${filename}.byTrans-result.txt  -o ${dir}/${filename}/${filename}.byTrans-result.csv
	sed -i '1i  PolyASite,siteRef,transID,geneID,Arecord,Meida,Average,Count ' ${dir}/${filename}/${filename}.byTrans-result.csv
	sed -i 's/,/\t/g'  ${dir}/${filename}/${filename}.byTrans-result.csv
	awk 'NR==FNR{a=substr($1,1,15);x[a]=$0} NR>FNR{$1=x[$1];print $0}' ~/Ref/Annotations/mouse/polyA/polyASites2GeneAndTrans.txt  ${dir}/${filename}/${filename}.byTrans-result.csv > ${dir}/${filename}/temp	
	mv ${dir}/${filename}/temp ${dir}/${filename}/${filename}.byTrans-result.tsv
	sed 's/\t/,/g' ${dir}/${filename}/${filename}.byTrans-result.tsv > ${dir}/${filename}/${filename}.byTrans-result.csv

        grep "ENSMUSG" ${dir}/${filename}/${filename}.byTrans-result.tsv|sort -k3|awk 'BEGIN{OFS=",";now="";record=""}{if($1!=now){print record;record=$3","$4","$5;now=$1}else{record=record";"$5}}END{if(now == $1){print record}}'|sed '1d'  > ${dir}/${filename}/${filename}.bygenes-result.txt
	~/script/myscript/C2T-seq/PolyA-counter/YH-3tail-static-perfect.py -i ${dir}/${filename}/${filename}.bygenes-result.txt  -o ${dir}/${filename}/${filename}.bygenes-result.csv
	sed -i '1i  Gene,geneRef,transID,geneID,Arecord,Meida,Average,Count ' ${dir}/${filename}/${filename}.bygenes-result.csv
	sed 's/,/\t/g ' ${dir}/${filename}/${filename}.bygenes-result.csv > ${dir}/${filename}/${filename}.bygenes-result.tsv
done <$1
