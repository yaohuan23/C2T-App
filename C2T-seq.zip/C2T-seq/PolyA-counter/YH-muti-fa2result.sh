#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source activate yaohuan23
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""
POLYAFA="/public23/home/sca2382/Ref/Annotations/human/PolyA/gencode.v44.polyAs.around200-nochr.fa"
SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
  if [ ! -f $1 ];then
  continue
  fi
  dir=${1%/*}
  filename1=${1%%.*}
  filename=${filename1##*/}
  cd ${dir}
    python ~/script/myscript/C2T-seq/PolyA-counter/YH-pre-caculate.py ${filename}.fa > ${filename}-merged.fa
    python ~/script/myscript/C2T-seq/PolyA-counter/YH-3tail-caculatedFR2.py ${filename}-merged.fa > ${filename}-result.fa
    python ~/script/myscript/C2T-seq/PolyA-counter/YH-3tail-staticR2.py  ${filename}-result.fa  ${filename}-length.txt
    grep ">" ${filename}-length.txt |sed 's/^>/chr/g' >${filename}-length-result.txt
#    rm ${filename}-merged.fa ${filename}-result.fa
}
while read line;
do
pipeline ${line}
done < $1
