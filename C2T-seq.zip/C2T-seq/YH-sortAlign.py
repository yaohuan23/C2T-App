import sys

def sort_sequences_by_last_non_dash(input_filename, output_filename):
    """
    Sorts sequences from an input file based on the position of the last non-dash character and writes the sorted sequences to an output file.
    
    Parameters:
    input_filename (str): The name of the input file containing the sequences.
    output_filename (str): The name of the output file where sorted sequences will be written.
    """
    
    def find_last_non_dash(sequence):
        """Returns the position of the last non-dash character in the sequence."""
        for i in range(len(sequence) - 1, -1, -1):
            if sequence[i] != '-':
                return i + 1
        return 0  # In case the sequence is full of dashes
    
    # Read sequences from the input file
    with open(input_filename, 'r') as file:
        sequences = file.readlines()
    
    # Strip newline characters and sort the sequences based on the last non-dash character's position
    sequences = [seq.strip() for seq in sequences]
    sorted_sequences = sorted(sequences, key=find_last_non_dash, reverse=True)
    
    # Write the sorted sequences to the output file
    with open(output_filename, 'w') as file:
        for seq in sorted_sequences:
            file.write(f"{seq}\n")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python sort_sequences.py <input_filename> <output_filename>")
        sys.exit(1)
    
    input_filename = sys.argv[1]
    output_filename = sys.argv[2]
    sort_sequences_by_last_non_dash(input_filename, output_filename)
