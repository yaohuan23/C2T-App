#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source activate yaohuan23
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
  if [ ! -f $1 ];then
  continue
  fi
  dir=${1%/*}
  filename1=${1%%_*}
  filename=${filename1##*/}
  cd ${dir}
  samtools view  ${filename}-Cap-Plus-4G.bam |awk 'match($6,/^[0-9]+S/){num=substr($6, RSTART, RLENGTH-1); print substr($10,num+1,20)}'|sort > ${filename}-m7Gbase20-Plus.txt
  awk '{print ">NUM"NR;print $0}' ${filename}-m7Gbase20-Plus.txt >${filename}-m7Gbase20-Plus.fa

  samtools view  ${filename}-Cap-minus-4G.bam|awk 'match($6,/[0-9]+S$/){num=substr($6, RSTART, RLENGTH-1); print substr($10,length($10)-num-19,20)}'|sort  > ${filename}-m7Gbase20-minus.txt
 awk '{print ">NUM"NR;print $0}' ${filename}-m7Gbase20-minus.txt >${filename}-m7Gbase20-minus.fa
 ~/script/myscript/C2T-seq/getReverse.py ${filename}-m7Gbase20-minus.fa >>${filename}-m7Gbase20-Plus.fa
 awk '{getline;print $0}' ${filename}-m7Gbase20-Plus.fa > ${filename}-m7Gbase20.txt 
 mv ${filename}-m7Gbase20-Plus.fa ${filename}-m7Gbase20.fa 
}
pipelineOne() {
while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  continue
  fi
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  cd ${dir}
  bamCoverage --binSize 1  --normalizeUsing RPKM -b ${line} -o ${filename}.bw &
done 
}
while read line;
do
pipeline ${line}
done < $1
