#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
  cd $2
 awk 'BEGIN{now=""}{if($1~/^>/){now=FNR;print $0 >"YHpolyAtemp"now".txt"}else{print $0 > "YHpolyAtemp"now".txt"}}' $1

}
pipseq(){
	cd $2
 	echo "sample $1 is being treated"
	awk 'BEGIN{num=0;jobnum=1}{if($1~/^>/){if(num<100){num+=1;print $0 > "seperatedjobs-"jobnum".txt"}else{num=1;jobnum+=1;print $0 > "seperatedjobs-"jobnum".txt"}}else{print $0 > "seperatedjobs-"jobnum".txt"}}' $1

}
pipelineOne() {
	cd $2
	filename1=${1%%.*}
	filename=${filename1##*/}
 	awk 'FNR<3{print $0} FNR>=3{print ">reads"FNR-2;print $0}'  $1 > ${filename}-temp-alin-1.txt
	python ~/script/myscript/C2T-seq/PolyA-counter/re-alignTreater.py ${filename}-temp-alin-1.txt |sort -k3|awk 'BEGIN{OFS="\t";nowP=""}{if($3!=nowP){print $1,$2,$3;print $4,$5,$6;nowP=$3}else{print $4,$5,$6}}' >>${filename}-Aligned-for-plot-CoutA-re.txt  
}

while read line;
do
	dir=${line%/*}
	filename1=${line%%.*}
	filename=${filename1##*/}
	mkdir ${dir}/${filename}
	pipseq ${line} ${dir}/${filename}
	wait
	find ${dir}/${filename} -name seperatedjobs\* > ${dir}/${filename}/${filename}-joblist.txt
	while read linea;
	do
		dir2=${linea%/*}
		filename1=${linea%%.*}
		filename2=${filename1##*/}
		mkdir ${dir2}/${filename2}
		pipeline ${linea} ${dir2}/${filename2}
		wait
		find ${dir2}/${filename2} -name YHpolyAtemp\* > ${dir2}/${filename2}/${filename2}-precal.txt
		while read lineb;
		do
			pipelineOne ${lineb}  ${dir2}/${filename2} & 
		done < ${dir2}/${filename2}/${filename2}-precal.txt  
		wait
		cat ${dir2}/${filename2}/*Aligned-for-plot-CoutA-re.txt > ${dir2}/${filename2}/result.txt
#		rm ${dir2}/${filename2}/YHpolyAtemp*.txt
#		rm ${dir2}/${filename2}/*temp-alin-1.txt
#	        rm ${dir2}/${filename2}/*Aligned-temp
#	        rm ${dir2}/${filename2}/*Aligned-temp.align.txt
#	        rm ${dir2}/${filename2}/*APA-star.LocalSite
#	        rm ${dir2}/${filename2}/*temp.fasta
		rm ${linea}
		rm ${dir2}/${filename2}/${filename2}-precal.txt
	done < ${dir}/${filename}/${filename}-joblist.txt  
	wait
	find ${dir}/${filename} -name result.txt|xargs cat > ${dir}/${filename}/${filename}.polyA-result.txt
	rm -r ${dir}/${filename}/seperatedjobs*
	awk 'BEGIN{precord="";pcount=0;count=0}{if($2 !~/reads/){pcount=0;count=0;FirstB=substr($1,1,1);transID=$2;seq=$1;pseq=$0} else{ if (FirstB == substr($1,1,1) ){if(count==0){count+=1;print ">"transID;print seq;print $1}else{print $1}}}}' ${dir}/${filename}/${filename}.polyA-result.txt > ${dir}/${filename}/${filename}-realign.txt
	awk 'BEGIN{precord="";pcount=0;count=0}{if($2 !~/reads/ && $1!~/reads/){pcount=0;count=0;FirstB=substr($1,1,1);transID=$2;seq=$1;pseq=$0} else{ if (FirstB != substr($1,1,1) && $1~/aaa/ ){if(count==0){count+=1;print pseq;print $0}else{print $0}}}}' ${dir}/${filename}/${filename}.polyA-result.txt > ${dir}/${filename}/${filename}-perfect.txt 
done <$1
