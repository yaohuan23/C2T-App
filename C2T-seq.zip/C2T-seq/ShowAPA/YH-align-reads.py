#!/public23/home/sca2382/.conda/envs/yaohuan23/bin/python
# this file is developed to filter the circRNA
from __future__ import print_function
from __future__ import division
from sys import stderr, exit
import sys
sys.path.append("/public23/home/sca2382/script/hisat2_RNA-seq/YH-tans-app")
from argparse import ArgumentParser, FileType
from src.samtreater import bedFilter
import re
from Bio import AlignIO
from Bio import SeqIO
if __name__ == '__main__':
    description=" This is used to write the aligned result of the polyA-reads "
    parser = ArgumentParser(description=description)
    help="you should input a fastFile which have the same length "
    parser.add_argument('-i','--inputfile',type=str,help=help)
    help = "you should input a file where the result to put"
    parser.add_argument('-o', '--output', type=str, help=help)
    args = parser.parse_args()

    if not args.inputfile:
        parser.print_help()
        exit(1)
    if args.__contains__("inputfile") and args.__contains__("output"):
        inputFa=args.inputfile
        outPutfile = args.output
        #print (outPutfile)
        #print(args.inputfile)
    else:
        print("you should in put a bedfile")
        exit(1)

    records = SeqIO.parse(inputFa, "clustal")
    count = SeqIO.write(records, outPutfile, "fasta")
    alignment = AlignIO.read(outPutfile, "fasta")
    for record in alignment:
        print("%s - %s" % (record.seq, record.id))

