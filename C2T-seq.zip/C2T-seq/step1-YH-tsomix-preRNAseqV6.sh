#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() {
  line = $1
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  filePair=${filename/_R1/_R2}
  filePair=${filePair/_1/_2}
  cd ${dir}
 	cutadapt -g CACGACGCTCTTCCGATCT -O19 -n5 -j0  -e 0.3 --action trim  -o ${dir}/${filename}_qua.fastq.gz  -p  ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}.fq.gz ${dir}/${filePair}.fq.gz
rm ${dir}/${filename}.fastq ${dir}/${filePair}.fastq
    #remove the muti-TSO sequence
      	cutadapt -g CACGTCTC -O8 -n5 -j0 -e 0 --action trim  -o ${dir}/${filePair}_good.fastq.gz  -p  ${dir}/${filename}_good.fastq.gz  ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}_qua.fastq.gz
rm ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}_qua.fastq.gz
        #remove the muti-adaptor sequence
	#cutadapt -j0  -a NNNNNNNAGATCGGA -a TCGGAAGAGCACAC  -A NNNNNNNAGATCGGA -A  TCGGAAGAGCACAC  -e0.2 -m 28  -O14 -o ${dir}/${filename}_trim.fastq -p ${dir}/${filePair}_trim.fastq ${dir}/${filename}_good.fastq.gz $dir/${filePair}_good.fastq.gz
zcat ${dir}/${filename}_good.fastq.gz> ${dir}/${filename}_trim.fastq
zcat ${dir}/${filePair}_good.fastq.gz> ${dir}/${filePair}_trim.fastq
  #gunzip ${dir}/${filename}.fastq.gz
  #gunzip ${dir}/${filePair}.fastq.gz
awk '{getline a; getline b; getline c;if(a ~ /^[ATGCN]{4,4}[GN]{3,3}/){print NR-3}}' ${dir}/${filename}_trim.fastq >${dir}/${filename}.record_FR_N4.txt
#get the righ reads according to the library structure
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_FR_N4.txt ${dir}/${filename}_trim.fastq >${dir}/${filename}_strand_N4.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_FR_N4.txt ${dir}/${filePair}_trim.fastq >${dir}/${filePair}_strand_N4.fastq
#remove the anchor sequence before the tso sequence
rm ${dir}/${filename}_trim.fastq ${dir}/${filePair}_trim.fastq
rm ${filename}.record_FR_N4.txt
awk '{getline a;getline b;getline c;print $0,substr(a,1,7),substr(a,8,14);print a;print b;print c}'  ${dir}/${filename}_strand_N4.fastq >${dir}/${filename}_N4PreV2.fastq
awk '{getline a;getline b;getline c;print $0,substr(a,1,6),substr(a,7,1),substr(a,8,14);print a;print b;print c}'  ${dir}/${filePair}_strand_N4.fastq >${dir}/${filePair}_N4PreV2.fastq
rm ${dir}/${filename}_strand_N4.fastq ${dir}/${filePair}_strand_N4.fastq
echo "awk '{nowLine=\$1\"-\"\$3\"-\"\$4;getline a;getline b;getline c;getline <\"${filePair}_N4PreV2.fastq\";print nowLine\"-\"\$3\"-\"\$4\"-\"\$5;print nowLine\"-\"\$3\"-\"\$4\"-\"\$5 > \"${filePair}_N4V2.fastq\";print a;print b;print c;getline d <\"${filePair}_N4PreV2.fastq\";getline e <\"${filePair}_N4PreV2.fastq\";getline f <\"${filePair}_N4PreV2.fastq\";print d > \"${filePair}_N4V2.fastq\";print e > \"${filePair}_N4V2.fastq\";print f >\"${filePair}_N4V2.fastq\"}' ${dir}/${filename}_N4PreV2.fastq > ${filename}_N4V2.fastq " > pre-temp.sh
sh pre-temp.sh
#write the correct file structure.
wait
rm ${dir}/${filename}_N4PreV2.fastq ${dir}/${filePair}_N4PreV2.fastq
awk 'BEGIN{FS="-";OFS="\t"}{print $2$3$4$5,NR;getline;getline;getline}' ${filename}_N4V2.fastq |sort -k1 >${filename}_N4.flag
awk '{if (x[$1] !=1){print $2;x[$1]=1}}' ${filename}_N4.flag|sort -n >${filename}_N4.uniq.record
awk 'NR==FNR{x[$1]=1} NR>FNR {if (x[FNR]==1){getline a;getline b;getline c;print $0;print a;print b;print c}}'  ${filename}_N4.uniq.record  ${filename}_N4V2.fastq > ${dir}/${filename}_N4uniq.fastq 
awk 'NR==FNR{x[$1]=1} NR>FNR {if (x[FNR]==1){getline a;getline b;getline c;print $0;print a;print b;print c}}'  ${filename}_N4.uniq.record  ${filePair}_N4V2.fastq > ${dir}/${filePair}_N4uniq.fastq 
rm ${filename}_N4V2.fastq ${filePair}_N4V2.fastq
rm ${filename}_N4.uniq.record
rm ${filename}_N4.flag
} 

while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  echo "noFile"${line}
  continue
  fi
echo 123
pipeline ${line} &
done <$1 2>&1
wait
