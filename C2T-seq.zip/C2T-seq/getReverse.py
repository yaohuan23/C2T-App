def reverse_complement(sequence):
    complement = {"A": "T", "T": "A", "C": "G", "G": "C", "N": "N"}
    reverse_sequence = sequence[::-1]
    reverse_complement_sequence = "".join(complement.get(base, base) for base in reverse_sequence)
    return reverse_complement_sequence

def reverse_complement_fasta(fasta_file):
    with open(fasta_file, "r") as file:
        lines = file.readlines()

    # 逐行处理FASTA文件
    reversed_lines = []
    for line in lines:
        line = line.strip()
        if line.startswith(">"):
            reversed_lines.append(line)  # 保留标题行
            print(line)
        else:
            reversed_sequence = reverse_complement(line)
            print(reversed_sequence) 
            reversed_lines.append(reversed_sequence)

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("请提供FASTA文件路径作为参数")
    else:
        fasta_file = sys.argv[1]
        reverse_complement_fasta(fasta_file)
