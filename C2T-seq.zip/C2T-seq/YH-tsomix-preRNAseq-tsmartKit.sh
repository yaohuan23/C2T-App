#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() {
  line =$1
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  filePair=${filename/_R1/_R2}
  filePair=${filePair/_1/_2}
  cd ${dir}
#gunzip ${dir}/${filename}.fq.gz
#mv  ${dir}/${filename}.fq ${dir}/${filename}.fastq
#gunzip ${dir}/${filePair}.fq.gz
mv  ${dir}/${filePair}.fq ${dir}/${filePair}.fastq
#awk '{getline a; getline b; getline c;if(a ~ /^[GN]{3,3}[ATC]{1,}/){print NR-3}}' ${dir}/${filename}.fastq >${dir}/${filename}_3G.txt
#awk '{getline a; getline b; getline c;if(a ~ /^[GN]{4,}/){print NR-3}}' ${dir}/${filename}.fastq >${dir}/${filename}_4G.txt
#awk '{getline a; getline b; getline c;if(a !~ /^[GN]{3,}/){print NR-3}}' ${dir}/${filename}.fastq >${dir}/${filename}_inter.txt
#get the righ reads according to the library structure
#awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_4G.txt ${dir}/${filename}.fastq >${dir}/${filename}_4G.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_4G.txt ${dir}/${filePair}.fastq >${dir}/${filePair}_4G.fastq


#awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_3G.txt ${dir}/${filename}.fastq >${dir}/${filename}_3G.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_3G.txt ${dir}/${filePair}.fastq >${dir}/${filePair}_3G.fastq


#awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_inter.txt ${dir}/${filename}.fastq >${dir}/${filename}_inter.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}_inter.txt ${dir}/${filePair}.fastq >${dir}/${filePair}_inter.fastq
} 

while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  echo "noFile"${line}
  continue
  fi
echo 123
pipeline ${line} &
done <$1 2>&1
wait
