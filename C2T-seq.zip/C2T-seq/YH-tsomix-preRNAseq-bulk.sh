#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source activate yaohuan23
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() {
  line = $1
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  filePair=${filename/_R1/_R2}
  filePair=${filePair/_1/_2}
  cd ${dir}
 	cutadapt -g CACGACGCTCTTCCGATCT -O19 -n5 -j0  -e 0.3 --action trim  -o ${dir}/${filename}_qua.fastq.gz  -p  ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}.fq.gz ${dir}/${filePair}.fq.gz
#rm ${dir}/${filename}.fastq ${dir}/${filePair}.fastq
    #remove the muti-TSO sequence
      	cutadapt -g CACGTCTC -O8 -n5 -j0 -e 0 --action trim  -o ${dir}/${filePair}_good.fastq.gz  -p  ${dir}/${filename}_good.fastq.gz  ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}_qua.fastq.gz
rm ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}_qua.fastq.gz
        #remove the muti-adaptor sequence
	cutadapt -j0 -a NNNNNNNAGATCGGA -a TCGGAAGAGCACAC  -A NNNNNNNAGATCGGA -A  TCGGAAGAGCACAC  -e0.2 -m 28  -O14 -o ${dir}/${filename}_through.fastq -p ${dir}/${filePair}_through.fastq ${dir}/${filename}_good.fastq.gz $dir/${filePair}_good.fastq.gz --untrimmed-output ${dir}/${filename}_trim1.fastq.gz --untrimmed-paired-output ${dir}/${filePair}_trim1.fastq.gz

	cutadapt -j0 -a GGGGGGGGGG -A GGGGGGGGGG   -m 35  -O9 -o ${dir}/${filename}_trim.fastq -p ${dir}/${filePair}_trim.fastq ${dir}/${filename}_trim1.fastq.gz $dir/${filePair}_trim1.fastq.gz
rm ${dir}/${filename}_good.fastq.gz $dir/${filePair}_good.fastq.gz
rm ${dir}/${filePair}_qua.fastq.gz ${dir}/${filename}_qua.fastq.gz
rm ${dir}/${filePair}_trim1.fastq.gz ${dir}/${filename}_trim1.fastq.gz

awk '{getline a;getline b;getline c;print $0,substr(a,1,7),substr(a,8,14);print a;print b;print c}'  ${dir}/${filename}_trim.fastq >${dir}/${filename}_N4PreV2.fastq
awk '{getline a;getline b;getline c;print $0,substr(a,1,6),substr(a,7,1),substr(a,8,14);print a;print b;print c}'  ${dir}/${filePair}_trim.fastq >${dir}/${filePair}_N4PreV2.fastq

awk '{getline a;getline b;getline c;print $0,substr(a,1,7),substr(a,8,14);print a;print b;print c}'  ${dir}/${filename}_through.fastq >${dir}/${filename}_throughV2.fastq
awk '{getline a;getline b;getline c;print $0,substr(a,1,6),substr(a,7,1),substr(a,8,14);print a;print b;print c}'  ${dir}/${filePair}_through.fastq >${dir}/${filePair}_throughV2.fastq
rm ${dir}/${filename}_through.fastq ${dir}/${filePair}_through.fastq
rm ${dir}/${filePair}_trim.fastq ${dir}/${filename}_trim.fastq
echo "awk '{nowLine=\$1\"-\"\$3\"-\"\$4;getline a;getline b;getline c;getline <\"${filePair}_N4PreV2.fastq\";print nowLine\"-\"\$3\"-\"\$4\"-\"\$5;print nowLine\"-\"\$3\"-\"\$4\"-\"\$5 > \"${filePair}_N4V2.fastq\";print a;print b;print c;getline d <\"${filePair}_N4PreV2.fastq\";getline e <\"${filePair}_N4PreV2.fastq\";getline f <\"${filePair}_N4PreV2.fastq\";print d > \"${filePair}_N4V2.fastq\";print e > \"${filePair}_N4V2.fastq\";print f >\"${filePair}_N4V2.fastq\"}' ${dir}/${filename}_N4PreV2.fastq > ${filename}_N4V2.fastq " > pre-temp.sh
sh pre-temp.sh
#write the correct file structure.
wait

rm ${dir}/${filename}_N4PreV2.fastq ${dir}/${filePair}_N4PreV2.fastq

awk '{getline a; getline b; getline c;if(a ~ /^[ATGCN]{4,4}[GN]{3,3}[ATC]{1,}/){print NR-3}}' ${dir}/${filename}_N4V2.fastq  >${dir}/${filename}.record_3G.txt
#get the righ reads according to the library structure
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_3G.txt ${dir}/${filename}_N4V2.fastq >${dir}/${filename}_3G.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_3G.txt ${dir}/${filePair}_N4V2.fastq >${dir}/${filePair}_3G.fastq

cutadapt -m 18 -q 30 -j 0  -a AAAAAAAAAANNNNNNN  -n 5 -G TTTTTTTTTT -O 9 -o ${dir}/${filename}_3G.fastq.gz -p ${dir}/${filePair}_3G.fastq.gz ${dir}/${filename}_3G.fastq ${dir}/${filePair}_3G.fastq
rm ${dir}/${filename}_3G.fastq ${dir}/${filePair}_3G.fastq

awk '{getline a; getline b; getline c;if(a ~ /^[ATGCN]{4,4}[GN]{4,}/){print NR-3}}' ${dir}/${filename}_N4V2.fastq  >${dir}/${filename}.record_4G.txt
##get the righ reads according to the library structure
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_4G.txt ${dir}/${filename}_N4V2.fastq >${dir}/${filename}_4G.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_4G.txt ${dir}/${filePair}_N4V2.fastq >${dir}/${filePair}_4G.fastq

cutadapt -m 18 -q 30 -j 0  -a AAAAAAAAAANNNNNNN  -n 5 -G TTTTTTTTTT -O 9 -o ${dir}/${filename}_4G.fastq.gz -p ${dir}/${filePair}_4G.fastq.gz ${dir}/${filename}_4G.fastq ${dir}/${filePair}_4G.fastq 
rm ${dir}/${filename}_4G.fastq ${dir}/${filePair}_4G.fastq


awk '{getline a; getline b; getline c;if(a ~ /^[ATCG]{7,12}TTTTT/){print NR-3}}' ${dir}/${filePair}_N4V2.fastq  >${dir}/${filename}.record_tail.txt
#get the righ reads according to the library structure
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_tail.txt ${dir}/${filename}_N4V2.fastq >${dir}/${filename}_tail.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_tail.txt ${dir}/${filePair}_N4V2.fastq >${dir}/${filePair}_tail.fastq
cutadapt -m 18 -q 30 -j 0  -a AAAAAAAAAANNNNNNN  -n 5 -G TTTTTTTTTT -O 9 -o ${dir}/${filename}_tail.fastq.gz -p ${dir}/${filePair}_tail.fastq.gz ${dir}/${filename}_tail.fastq ${dir}/${filePair}_tail.fastq

rm ${filename}_N4V2.fastq ${filePair}_N4V2.fastq

echo "awk '{nowLine=\$1\"-\"\$3\"-\"\$4;getline a;getline b;getline c;getline <\"${filePair}_throughV2.fastq\";print nowLine\"-\"\$3\"-\"\$4\"-\"\$5;print nowLine\"-\"\$3\"-\"\$4\"-\"\$5 > \"${filePair}_N4V2.fastq\";print a;print b;print c;getline d <\"${filePair}_throughV2.fastq\";getline e <\"${filePair}_throughV2.fastq\";getline f <\"${filePair}_throughV2.fastq\";print d > \"${filePair}_N4V2.fastq\";print e > \"${filePair}_N4V2.fastq\";print f >\"${filePair}_N4V2.fastq\"}' ${dir}/${filename}_throughV2.fastq > ${filename}_N4V2.fastq " > pre-temp.sh
sh pre-temp.sh
#write the correct file structure.
wait
awk '{getline a; getline b; getline c;if(a ~ /^[ATCG]{7,12}TTTTT/){print NR-3}}' ${dir}/${filePair}_N4V2.fastq  >${dir}/${filename}.record_tail.txt
#get the righ reads according to the library structure
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_tail.txt ${dir}/${filename}_N4V2.fastq >${dir}/${filename}_through-tail.fastq
awk 'NR==FNR{x[$1]=1} NR>FNR && x[FNR]==1{getline a; getline b; getline c;print $0;print a;print b;print c}'  ${dir}/${filename}.record_tail.txt ${dir}/${filePair}_N4V2.fastq >${dir}/${filePair}_through-tail.fastq
rm ${filename}_N4V2.fastq ${filePair}_N4V2.fastq

} 

while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  echo "noFile"${line}
  continue
  fi
echo 123
pipeline ${line} &
done <$1 2>&1
wait
