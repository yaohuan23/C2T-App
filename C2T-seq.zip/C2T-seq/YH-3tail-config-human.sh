#!/bin/bash
## Configuration file for rnaseq_pipeline.sh
##
## Place this script in a working directory and edit it accordingly.
##

#while read line ;do dir=${line%/*}; filename1=${line%%.*}; sample=${filename1##*/}; dsample="${sample%%_*}";mv ${line} ${dir}/${dsample}.bam; done < input.txt 

## The default configuration assumes that the user unpacked the 
## chrX_data.tar.gz file in the current directory, so all the input
## files can be found in a ./chrX_data sub-directory
#how many CPUs to use on the current machine?
NUMCPUS=31

#### Program paths ####

## optional BINDIR, using it here because these programs are installed in a common directory
#BINDIR=/usr/local/bin
#SAMTOOLS=$BINDIR/samtools
STAR=$(which STAR)
#if these programs are not in any PATH directories, please edit accordingly:
HISAT2=$(which hisat2)
STRINGTIE=$(which stringtie)
SAMTOOLS=$(which samtools)
POLYAFA="/public23/home/sca2382/Ref/Annotations/human/PolyA/gencode.v44.polyAs.around200-nochr.fa"

#POLYAFA="/public23/home/sca2382/Ref/Annotations/mouse/polyA/gencode.vM25.polyAsAround200.fa"

#### File paths for input data
### Full absolute paths are strongly recommended here.
## Warning: if using relatives paths here, these will be interpreted 
## relative to the  chosen output directory (which is generally the 
## working directory where this script is, unless the optional <output_dir>
## parameter is provided to the main pipeline script)

## Optional base directory, if most of the input files have a common path
#BASEDIR="/home/johnq/RNAseq_protocol/chrX_data"
#BASEDIR=$(pwd -P)/chrX_data

#FASTQLOC=""
inputFa="/public23/home/sca2382/Fastq/PolyAlib/PE150/human/input.txt"
GENOMEIDX="/public23/home/sca2382/Ref/Annotations/human/PolyA/polyA"
#GENOMEIDX="/public23/home/sca2382/Ref/Annotations/mouse/polyA/polyA"
#STR_GENOMEIDX="/workplace/yaohuan/ref/mouse/mm10/STAR/"
#GTFFILE="/public1/home/sca2382/Ref/hg38_tran/hg38_ucsc.annotate/hg38_ucsc.annotated.gtf"
GTFFILE="/public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.annotation.gtf"
#GENOMEIDX="/workplace/yaohuan/ref/mouse/mm10/genecodeV22-mouse/gencode.vM22.polyAs"
#GENOMEIDX="/workplace/yaohuan/ref/mouse/mm10/gencode.vM22.polyAs220/gencode.vM22.polyAs220"
#/workplace/yaohuan/ref/mouse/mm10/all-cDNA/mm10-cDNA
#GENOMEIDX="/workplace/yaohuan/ref/human/hg19/trans/hg19_trans"
#GTFFILE=""
PHENODATA="/PGD2/yaohuan/circular_RNA/clean_data/sample_list.csv"
tRNAhtIndex="/PGD1/ref/yangxin_here/Human/tRNA/trna_index"
rRNAIndex="/PGD1/ref/yangxin_here/Human/45S_Human/hisat2Index/45SIndex"
TEMPLOC="./tmp" #this will be relative to the output directory
#for tmp_file in `ls ${FASTQLOC}/*index1.fastq.gz`
#do
#reads1=(${reads1[*]} $tmp_file)
#done
while read line 
do
	reads1=(${reads1[*]} $line)
done <$inputFa
## list of samples 
## (only paired reads, must follow _1.*/_2.* file naming convention)
#reads1=(${FASTQLOC}/*_1.fastq.gz)
reads2=("${reads1[@]/_R1/_R2}")
reads2=("${reads2[@]/_1_/_2_}")
reads1_name=("${reads1[@]##*/}")
reads2_name=("${reads1[@]/_R1/_R2}")
reads2_name=("${reads2[@]/_1_/_2_}")
#echo ${reads2[1]}
