#!/bin/sh
#get the m7G sites by non-template G
samtools view -H minus-4G.bam > Cap-Plus-4G.sam
samtools view -f64 -F4 -q 40 minus-4G.bam|grep "XS:A:+"|awk '$6~/[1-4]S[2-9][1,9]+M/{print $0}'|awk 'match($6,/[1-4]S/){num=substr($6, RSTART, RLENGTH-1);if(substr($10,1,num)~/^[GN]$/){print $0}}' >> Cap-Plus-4G.sam
samtools view -bh Cap-Plus-4G.sam > Cap-Plus-4G.bam
bedtools bamtobed -i Cap-Plus-4G.bam > Cap-Plus-4G.bed
awk '{OFS="\t";$3=$2+1;print $0}' Cap-Plus-4G.bed > temp
mv temp Cap-Plus-4G.bed
#Generate the Cap-bam from 3G data
samtools view -bh -f64 -F4 -q 40 minus-3G.bam >R1-minus-3G.bam
bedtools bamtobed -i R1-minus-3G.bam > minus-3G.bed
intersectBed -a minus-3G.bed -b Cap-Plus-4G.bed  -wa -wb|awk '($2-$8)*($2-$8)<=10{if($6==$12){print $0}}'|cut -f4 |uniq|sed 's#/1##g' > G3-uniq.txt
samtools view -H  minus-3G.bam >Cap-Plus-3G.sam
samtools view  R1-minus-3G.bam > minus-3G.sam
awk 'NR==FNR{x[$1]=1}NR>FNR{if(x[$1]==1){print $0}}' G3-uniq.txt minus-3G.sam >> Cap-Plus-3G.sam 
samtools view -bh Cap-Plus-3G.sam > Cap-Plus-3G.bam
#samtools merge Cap-Plus.bam  Cap-Plus-3G.bam Cap-Plus-4G.bam
####
#Generate the Cap-bam from 4G data
samtools view -bh -f64 -F4 -q 40 minus-4G.bam >R1-minus-4G.bam
bedtools bamtobed -i R1-minus-4G.bam > minus-4G.bed
intersectBed -a minus-4G.bed -b Cap-Plus-4G.bed  -wa -wb|awk '($2-$8)*($2-$8)<=10{if($6==$12){print $0}}'|cut -f4 |uniq|sed 's#/1##g' > G4-uniq.txt
samtools view -H  minus-4G.bam >Cap-Plus-4G.sam
samtools view  R1-minus-4G.bam > minus-4G.sam
awk 'NR==FNR{x[$1]=1}NR>FNR{if(x[$1]==1){print $0}}' G4-uniq.txt minus-4G.sam >> Cap-Plus-4G.sam 
samtools view -bh Cap-Plus-4G.sam > Cap-Plus-4G.bam
samtools merge Cap-Plus.bam  Cap-Plus-3G.bam Cap-Plus-4G.bam
####

#The reverse genes
samtools view -H minus-4G.bam > Cap-minus-4G.sam
samtools view -f64 -F4 -q 40 minus-4G.bam|grep "XS:A:-"|awk '$6~/[2-9][1-9]+M[1-4]S/{print $0}' |awk 'match($6,/[1-4]S$/){num=substr($6, RSTART, RLENGTH-1);if(substr($10,1,num)~/^[GN]$/){print $0}}' >> Cap-minus-4G.sam
samtools view -bh Cap-minus-4G.sam > Cap-minus-4G.bam
bedtools bamtobed -i Cap-minus-4G.bam > Cap-minus-4G.bed
awk '{OFS="\t";$2=$3-1;print $0}' Cap-minus-4G.bed > temp
mv temp Cap-minus-4G.bed
#
#samtools view -f64 -F4 -q 40 minus-3G.bam >R1-minus-3G.bam
#bedtools bamtobed -i R1-minus-3G.bam > minus-3G.bed
intersectBed -a minus-3G.bed -b Cap-minus-4G.bed  -wa -wb|awk '($3-$8)*($3-$8)<=10{if($6==$12){print $0}}'|cut -f4 |uniq|sed 's#/1##g' > G3-uniq.txt
samtools view -H  minus-3G.bam >Cap-minus-3G.sam
#samtools view  R1-minus-3G.bam > minus-3G.sam
awk 'NR==FNR{x[$1]=1}NR>FNR{if(x[$1]==1){print $0}}' G3-uniq.txt minus-3G.sam >> Cap-minus-3G.sam 
samtools view -bh Cap-minus-3G.sam > Cap-minus-3G.bam
#samtools merge Cap-minus.bam  Cap-minus-3G.bam Cap-minus-4G.bam
##

intersectBed -a minus-4G.bed -b Cap-minus-4G.bed  -wa -wb|awk '($3-$8)*($3-$8)<=10{if($6==$12){print $0}}'|cut -f4 |uniq|sed 's#/1##g' > G4-uniq.txt
samtools view -H  minus-4G.bam >Cap-minus-4G.sam
#samtools view  R1-minus-3G.bam > minus-3G.sam
awk 'NR==FNR{x[$1]=1}NR>FNR{if(x[$1]==1){print $0}}' G4-uniq.txt minus-4G.sam >> Cap-minus-4G.sam 
samtools view -bh Cap-minus-4G.sam > Cap-minus-4G.bam
samtools merge Cap-minus.bam  Cap-minus-3G.bam Cap-minus-4G.bam
