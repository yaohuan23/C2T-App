#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipeline() { 
  echo "sample $1 is being treated"
 awk 'BEGIN{now=""}{if($1~/^>/){now=FNR;print $0 >"YHpolyAtemp"now}else{print $0 > "YHpolyAtemp"now}}' $1

}
pipelineOne() {
  awk 'FNR<3{print $0} FNR>=3{print ">reads"FNR-2;print $0}'  $1 > temp-alin-1.txt
  mafft --reorder  --quiet --auto --clustalout --localpair --thread 8 temp-alin-1.txt > Aligned-temp
 ~/script/myscript/YH-align-reads.py -i Aligned-temp -o Aligned-temp.fasta > Aligned-temp.align.txt
  grep -v "read" Aligned-temp|awk 'FNR>3 {print $0}'|sed 's/ /-/g' |cut -c17-180|awk '{getline;print $0;getline}'|xargs|sed  's/ //g'|awk '{print $0 >>"aligin-record.txt";print "" > "aligin-record.txt";match($0,/([\*,\.]{1,}[-]{0,1}[\*]{1,})([-,\*,\.]{1,})/,a);match(a[2],/([\*,\.]{1,}[-]{0,1}[\*]{1,})([-,\*,\.]{1,})/,b);if(length(a[1])>0){if(length(b[1])>0){a[2]=b[2]};print length($0)-length(a[2])}else{print 0}}' > APA-star.LocalSite
 awk 'BEGIN{a=0}NR==FNR{a=$0}NR>FNR{if(a>0){print substr($0,a+1,length($0))}else{print substr($0,a+1,length($0)) >> "Aligned-for-plot-CoutA-notAlign.txt"}}' APA-star.LocalSite Aligned-temp.align.txt |sed 's/-//g'|sed 's/  /\t/g'|awk 'NR==1{print $0"\t"$2}NR>1{print $0"\t"length($1)}' >>Aligned-for-plot-CoutA-re.txt
}

while read line;
do
pipeline ${line}
wait

	dir=${line%/*}
	filename1=${line%%.*}
	filename=${filename1##*/}

	find ${dir} -name YHpolyAtemp\* > ${filename}-precal.txt

	while read line;
	do
		pipelineOne ${line}
	done < ${filename}-precal.txt
wait
done < $1 
