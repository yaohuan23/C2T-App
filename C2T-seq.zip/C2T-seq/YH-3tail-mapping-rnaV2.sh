#!/bin/bash
#SBATCH -p amd_256
#SBATCH -N 1
#SBATCH -n 1
#SBATCH -c 64
source activate yaohuan23
module load seqkit/0.13.2
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME} [output_dir]
Wrapper script for HISAT2/StringTie RNA-Seq analysis protocol.
In order to configure the pipeline options (input/output files etc.)
please copy and edit a file rnaseq_pipeline.config.sh which must be
placed in the current (working) directory where this script is being launched.

Output directories "hisat2" and "ballgown" will be created in the
current working directory or, if provided, in the given <output_dir>
(which will be created if it does not exist).

EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

## load variables
if [[ ! -f $2 ]]; then
 usage
 echo "Error: configuration file (rnaseq_pipeline.config.sh) missing!"
 exit 1
fi

source $2
WRKDIR=$(pwd -P)
errprog=""
if [[ ! -x $SAMTOOLS ]]; then
    errprog="samtools"
fi
if [[ ! -x $HISAT2 ]]; then
    errprog="hisat2"
fi
if [[ ! -x $STRINGTIE ]]; then
    errprog="stringtie"
fi

if [[ "$errprog" ]]; then
  echo "ERROR: $errprog program not found, please edit the configuration script."
  exit 1
fi

#if [[ ! -f rnaseq_ballgown.R ]]; then
#   echo "ERROR: R script rnaseq_ballgown.R not found in current directory!"
#   exit 1
#fi

#determine samtools version
newsamtools=$( ($SAMTOOLS 2>&1) | grep 'Version: 1\.')
set -e
#set -x

if [[ $OUTDIR != "." ]]; then
  mkdir -p $OUTDIR
  cd $OUTDIR
fi

SCRIPTARGS="$@"
ALIGNLOC=$OUTDIR/hisat2
BALLGOWNLOC=$OUTDIR/ballgown

LOGFILE=$OUTDIR/run.log

for d in "$TEMPLOC" "$ALIGNLOC" "$BALLGOWNLOC" ; do
 if [ ! -d $d ]; then
    mkdir -p $d
 fi
done

# main script block
pipeline() {

echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> START: " $0 $SCRIPTARGS

for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    #sample="${sample%%_*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    echo [$stime] "   * Alignment of reads to genome (HISAT2)"
    cutadapt -m18 -a AAAAAAAAAA  -n 10 -O 9 -q30 -o ${TEMPLOC}/${sample}_1.fastq  -p ${TEMPLOC}/${sample}_2.fastq ${reads1[$i]} ${reads2[$i]}
    NGmerge -1 ${TEMPLOC}/${sample}_1.fastq -2  ${TEMPLOC}/${sample}_2.fastq -o ${ALIGNLOC}/${sample}-paire.fastq -l ${TEMPLOC}/${sample}-pairelog.txt  -f ${TEMPLOC}/${sample}-Toolong -n 32 -u 41 -g -m 10 -p 0.2 
    seqkit seq ${TEMPLOC}/${sample}-Toolong_2.fastq -r -p -t DNA -j 32 > temp.fastq
    mv ${TEMPLOC}/${sample}-Toolong_1.fastq ${TEMPLOC}/${sample}-Toolong_R1.fastq
    mv temp.fastq  ${TEMPLOC}/${sample}-Toolong_1.fastq
if [[ ! -f ${TEMPLOC}/${sample}-10.bam ]];then
     $HISAT2 -p $NUMCPUS  -x ${GENOMEIDX} \
     -U  ${TEMPLOC}/${sample}_1.fastq \
     --rna-strandness F --add-chrname -5 7  \
     |samtools view -F4 -Sb >${TEMPLOC}/${sample}-0.bam 2>${ALIGNLOC}/${sample}.alnstats &
fi
wait
    samtools view -q40 ${TEMPLOC}/${sample}-0.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-0-poly.record
    cat ${ALIGNLOC}/${sample}-0-poly.record  > ${ALIGNLOC}/${sample}-poly.record
    awk '$1 ~/-*TTTTT*$/{print "@"$0}' ${ALIGNLOC}/${sample}-poly.record|sort|uniq |sort -k2> ${ALIGNLOC}/${sample}-r3tURecord.txt
    sed -i 's/\tchr/\t/g' ${ALIGNLOC}/${sample}-r3tURecord.txt 
    awk 'BEGIN{nowSite=""}{if(nowSite==$2){print $1}else{print ">"$2;print $1;nowSite=$2}}' ${ALIGNLOC}/${sample}-r3tURecord.txt > ${ALIGNLOC}/${sample}-pre.fa
    awk 'NR==FNR{getline a; x[$1]=a}NR>FNR{if(x[$1]){print $1;print x[$1]}else{print $0}}' ${POLYAFA} ${ALIGNLOC}/${sample}-pre.fa > ${ALIGNLOC}/${sample}-pre-1.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,1,length(a)-7);getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${ALIGNLOC}/${sample}-paire.fastq  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-polyA.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,1,length(a)-7);getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${TEMPLOC}/${sample}-Toolong_1.fastq  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-ToolongPolyA.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,8,length(a));getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${reads1[$i]}  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-ToolongPolyA2.fa
    awk 'NR==FNR{getline a; x[$1]=substr(a,8,length(a));getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}' ${TEMPLOC}/${sample}-Toolong_R1.fastq  ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-ToolongPolyA3.fa
    grep -v "@" ${ALIGNLOC}/${sample}-polyA.fa > ${sample}-temp
    mv ${sample}-temp  ${ALIGNLOC}/${sample}-polyA.fa
    grep -v "@" ${ALIGNLOC}/${sample}-ToolongPolyA.fa> ${sample}-temp
    mv ${sample}-temp  ${ALIGNLOC}/${sample}-ToolongPolyA.fa
done
echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> DONE."
} #pipeline end


pipelineTwo() {

echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> START: " $0 $SCRIPTARGS

for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    #sample="${sample%%_*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    echo [`date +"%Y-%m-%d %H:%M:%S"`] "   * Alignments conversion (SAMTools)"
if [[ ! -f ${ALIGNLOC}/${sample}-3tURecord.txt ]]; then  
	intersectBed -a ${TEMPLOC}/${sample}-0.bam  -b ${POLYAGTF} > ${ALIGNLOC}/${sample}-0-poly.bam
fi

done
echo [`date +"%Y-%m-%d %H:%M:%S"`] "#> DONE."
} #pipeline end


pipelineThree() {
for ((i=0; i<=${#reads1[@]}-1; i++ )); do
    sample="${reads1_name[$i]%%_index*}"
    stime=`date +"%Y-%m-%d %H:%M:%S"`
    echo "[$stime] Processing sample: $sample"
    samtools view ${TEMPLOC}/${sample}-0.bam|cut -f1,3 > ${ALIGNLOC}/${sample}-0-poly.record
    awk '$1 ~/-*TTTTT*$/{print "@"$0}' ${ALIGNLOC}/${sample}-0-poly.record|sort|uniq |sort -k2> ${ALIGNLOC}/${sample}-r3tURecord.txt
    sed -i 's/\tchr/\t/g' ${ALIGNLOC}/${sample}-r3tURecord.txt 
    awk 'BEGIN{nowSite=""}{if(nowSite==$2){print $1}else{print ">"$2;print $1;nowSite=$2}}' ${ALIGNLOC}/${sample}-r3tURecord.txt > ${ALIGNLOC}/${sample}-pre.fa
awk 'NR==FNR{getline a; x[$1]=a}NR>FNR{if(x[$1]){print $1;print x[$1]}else{print $0}}' /public23/home/sca2382/Ref/Annotations/mouse/polyA/gencode.vM25.polyAsAround200.fa ${ALIGNLOC}/${sample}-pre.fa > ${ALIGNLOC}/${sample}-pre-1.fa
awk 'NR==FNR{getline a; x[$1]=a;getline;getline}NR>FNR{if(x[$1]){print  x[$1]}else{print $0}}'   ${ALIGNLOC}/${sample}-pre-1.fa > ${ALIGNLOC}/${sample}-polyA.fa
done
} #pipline END

pipeline 2>&1 | tee $LOGFILE
#wait
#pipelineTwo 2>&1 | tee $LOGFILE
#wait
#pipelineThree 2>&1 | tee $LOGFILE
#wait
