#!/bin/bash
usage() {
    NAME=$(basename $0)
    cat <<EOF
Usage:
  ${NAME}  <input.fastq.gz> 
  record all the fastq.gz file location in a absolute formate 
EOF
}

OUTDIR=$(pwd -P)
if [[ "$1" ]]; then
 if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  usage
  exit 1
else
OUTDIR=$1
fi
fi

WRKDIR=$(pwd -P)
errprog=""

SCRIPTARGS="$@"
# main script block
pipelineTwo() {
while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  continue
  fi
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  cd ${dir}
 multiBamSummary BED-file -p 64 -b ${line} --outRawCounts ${filename}_Total.couts  --BED /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.annotation-single-BinRelative.bed12 & 
 multiBamSummary BED-file -p 64 -b ${line} --outRawCounts ${filename}_Relative.couts  --BED /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.annotation-single-relative.bed12 & 
 multiBamSummary BED-file -p 64 -b ${line} --outRawCounts ${filename}_promoter200.couts  --BED /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.annotation-single-before200.bed12 & 
done
}
pipelineThree() {
while read line;
do
  echo "sample $line is being treated"
  if [ ! -f $line ];then
  continue
  fi
  dir=${line%/*}
  filename1=${line%%.*}
  filename=${filename1##*/}
  cd ${dir}
 awk 'NR==FNR{x[$1$2$3]=$4}NR>FNR{print $6"\t"$5"\t"x[$1$2$3]}'   ${filename}_Total.couts  /public23/home/sca2382/Ref/Annotations/mouse/gencode.vM25.annotation-single-BinRelative.lable |awk 'BEGIN{OFS="\t"}{$3=$3+x[$1$2];x[$1$2]=$3;print $0}' > ${filename}-temp2
 awk 'BEGIN{nowPosition="";last=""}{if(x[$1$2]!=$1$2){print last};x[$1$2]=$1$2;last=$0}END{print last}' ${filename}-temp2 |sed '1d'> ${filename}-temp3
 cut -f1,3 ${filename}-temp3|sort -n|awk 'BEGIN{OFS="\t"}{$2=$2+x[$1];x[$1]=$2;print $0}'|awk 'BEGIN{nowPosition="";last=""}{if(x[$1]!=$1){print last};x[$1]=$1;last=$0}END{print last}'|sed '1d' > ${filename}_predis_less3K.txt
 awk 'BEGIN{OFS="\t"}NR==FNR{x[$1]=$2}NR>FNR{if(x[$1]>0){print $1,$2,100*$3/x[$1]}}'  ${filename}_predis_less3K.txt  ${filename}-temp3 > ${filename}-normalized-matrix.txt

 awk 'BEGIN{ printf "TransID "; for (i = 1; i <= 50; i++) { printf "%s ", i }; printf "\n" }' > ${filename}-temp

awk '{ lines[NR] = $3 } NR % 50 == 0 { if ($2 == 1.00) { printf $1" ";for (i = NR; i >= NR - 49; i--) { printf "%s ", lines[i] }; printf "\n" } else { printf $1" ";for (i = NR - 49; i <= NR; i++) { printf "%s ", lines[i] }; printf "\n" } } END { if (NR % 50 != 0) { for (i = NR - (NR % 50) + 1; i <= NR; i++) { printf "%s ", lines[i] }; printf "\n" } }' ${filename}-normalized-matrix.txt  >> ${filename}-temp


 mv ${filename}-temp ${filename}-normalized-matrix.txt

done
}
#pipelineOne<$1 2>&1 &
#pipelineTwo<$1 2>&1 
#wait
pipelineThree<$1 2>&1
wait

